/// <reference path="data.d.ts" />
/// <reference path="console.d.ts" />
import "MY_GLOBAL_SECRET" 
//console.log($)
console.log(x)