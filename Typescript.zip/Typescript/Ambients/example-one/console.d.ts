declare var x:{
    log(message?: any, ...optionalParams: any[]): void;
}


