import secretMessage from "./modules/calculator/constants/secretMessage";
import addNum from "./modules/calculator/functions/addNum";
import divideNum from "./modules/calculator/functions/divideNum";
import multiplyNum from "./modules/calculator/functions/multiplyNum";
import subNum from "./modules/calculator/functions/subNum";

const addition = addNum(100, 200)
const multiplication = multiplyNum(25, 25)
const division = divideNum(10, 2)
const subtraction = subNum(5, 5)
console.log(
    addition,
    multiplication,
    division,
    subtraction
)
console.log(secretMessage)



