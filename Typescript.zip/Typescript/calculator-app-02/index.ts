import Common from "./namespaces/common";


const addition = Common.addNum(100,200)
const multiplication = Common.multiplyNum(5,5)
const division = Common.divideNum(10,2)
const subtraction = Common.subNum(5,5)

console.log(
    addition,
    multiplication,
    division,
    subtraction
)


