const netflix_subscription: boolean = true
if (netflix_subscription === true) {
    console.log("Proceed to Login!!!")
}
else {
    console.log("Your subscription is not active!!")
}

