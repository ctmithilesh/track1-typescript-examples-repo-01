const age: number  = 25

console.log(age)


