const secretMessage: string = "Dont use Internet Explorer in 2023"

export default secretMessage;


