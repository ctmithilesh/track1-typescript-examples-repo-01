const salesData: Array<number> = [
    300,
    34634,
    25356234,15,
    343,
    45,
    4354,
    435,
    57,
    76,
    23,
    5467
]
console.log(salesData)
// Maximum Sales Figure
const maxSales = Math.max(...salesData)
console.log(maxSales)