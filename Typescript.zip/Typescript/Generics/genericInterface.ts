// accepts any data type
interface Todos<T>{
    contents:T
}

const stringTodo: Todos<string> = { contents: "The food was good" }
const numberTodo: Todos<number> = { contents: 242423432432 }

console.log(stringTodo.contents)
console.log(numberTodo.contents)


