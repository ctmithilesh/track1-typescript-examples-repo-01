function divideNum(x: number, y: number): number {
    const result = x / y
    return result
}
export default divideNum;



