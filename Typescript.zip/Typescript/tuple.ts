// typescript array with data type number
const numbers: Array<number> = [100,200,300,400,500]
console.log(numbers)

// typescript tuple 
const empDetails: [number, string, string] = [1,"Vijay Kumar","Sr.Project Manager"]
console.log(empDetails)





