// code that is outside typescript can be declared here 
declare const $: any;
declare const MY_GLOBAL_SECRET: string;




