const first_name: string = "Vijay"
const last_name: string = "Singh"
let address: string = "New Delhi"
let designation: string = "Software Architect"
let contact: number = 32553434

console.log(
    first_name,
    last_name,
    address,
    designation,
    contact
)



