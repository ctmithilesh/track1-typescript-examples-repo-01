namespace Banking{


export class Bank{

    constructor(
        public bank_name: string,
        public bank_branch: string,
        public branch_manger: string
    ){

    }

    public displayBankName(){
        console.log(`The Bank Name is ${this.bank_name}`)
    }
}
export class Customer extends Bank{

    constructor(
        public accountNumber: number,
        public accountName: string,
        public balance: number
    ){
        super("SBI","Pune","Jiten Gandhi")
    }

    deposit(amount: number): void{
        this.balance = this.balance + amount
        console.log(`You deposited INR ${amount}`)
        console.log(`The New Balance is ${this.balance}`)

    }
    withdraw(amount: number): number{
        this.balance = this.balance - amount
        console.log(`You withdrew INR ${amount}`)
        console.log(`The New Balance is ${this.balance}`)
        return this.balance
    }
    checkBalance(){
        console.log(`Dear Customer, your balance is ${this.balance}`)

    }
}



}
export default Banking