const numbers: Array<number> = [
    100,
    200,
    400,
    600,
    700,
    800,
    900
]
const countries: Array<string> = [
    'India',
    'Australia',
    'Canada',
    'China',
    'Russia',
    'Germany',
    'Taiwan'
]
const salesData: Array<object> = [
    {
        sales_person:'Steve',
        sales_amount:15000
    },
    {
        sales_person:'John',
        sales_amount:5000
    },
    {
        sales_person:'Roger',
        sales_amount:7000
    },
]
function findLength<Type>(myArr: Type[]):number{
    return myArr.length
}

const lengthOfNumbersArray = findLength(numbers)
const lengthOfCountriesArray = findLength(countries)
const lengthOfSalesDataArray = findLength(salesData)

console.log('Length of Numbers Array',lengthOfNumbersArray)
console.log('Lenght of Countries Array',lengthOfCountriesArray)
console.log('Length of Sales Data Array',lengthOfSalesDataArray)




