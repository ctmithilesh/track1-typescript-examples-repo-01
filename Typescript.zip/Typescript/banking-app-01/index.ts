import Banking from "./namespaces/banking";
import Borrowing from "./namespaces/borrowing";


const b1 = new Banking.Bank("Bank of Baroda","Delhi","Amit Kumar")
const c1 = new Banking.Customer(656456,"Divya Sharma",5000)

b1.displayBankName()
c1.deposit(5000)
c1.deposit(3000)
c1.withdraw(1000)

const l1 = new Borrowing.Loan('Ankit Gupta',100000,2,10)

l1.viewLoanAmount()
l1.payInstallment(5000)
l1.payEntireLoan()



