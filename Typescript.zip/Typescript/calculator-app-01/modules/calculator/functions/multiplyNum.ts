function multiplyNum(x: number,y: number): number{
    const result = x*y
    return result
}
export default multiplyNum;

