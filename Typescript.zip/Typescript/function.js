function addNum(x,y){
    return x+y
}

const result = addNum(100,500)
console.log(result)