import Banking from "./banking";

namespace Borrowing{


    export class Loan extends Banking.Bank{

            constructor(
                public customer_name: string,
                public loan_amount: number,
                public loan_duration_in_years: number,
                public loan_interest: number
            ){
                super('Indusind Bank','Haryana','Vineet Gupta')
            }

        viewLoanAmount(){
            console.log(`Your Loan Amount is INR ${this.loan_amount}`)

        }
        payInstallment(amount: number){
            const remaining_loan_amount = this.loan_amount - amount
            console.log(`You successfully paid the amount of ${amount}`)
            console.log(`Your remaining Loan is now ${remaining_loan_amount}`) 
            return remaining_loan_amount

        }
        payEntireLoan(): void{
            const loan_amount = this.loan_amount
            const remaining_loan_amount =  loan_amount - loan_amount
            console.log(`You have cleared your entire Loan of ${this.loan_amount}`)
            console.log(`You have INR ${remaining_loan_amount } pending dues`)
        }


    }
}
export default Borrowing;

