const person: object = {
    height: '5 8',
    gender: 'male',
    age: 'asfsafga',
    name: 'Ajay Kumar',
    address: 'Delhi',
    marial_status: 'unmarried',
    languages:['English','Marathi','Hindi','Telegu'],
    govt_details:{
        pan_card:"AV445E",
        driving_license:"DBV35235"
    }
}

// Print the languagues
console.log(person)