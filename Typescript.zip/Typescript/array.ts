const numbers: Array<number> = [100,200,300,400,500]

console.log(numbers)