class Items<T>{

    private items: T[] = []


    push(item: T){
        this.items.push(item)
    }
    pop(): T | undefined  {
        return this.items.pop()
    }
    display(): void{
        console.log(this.items)
    }

}
const t1 = new Items()
t1.display()
t1.pop()
t1.display()

// t1.push('India')
// t1.push(200)
// t1.push({country_name:'Germany'})
// t1.push([400,500,600])
// t1.push('America')
// t1.display()
// t1.pop()
// t1.display()


