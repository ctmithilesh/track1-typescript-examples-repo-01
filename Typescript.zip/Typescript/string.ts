let country: string = "India"

console.log(country)
