const numbers: Array<number> = [
    100,
    200,
    400,
    600,
    700,
    800,
    900
]
const countries: Array<string> = [
    'India',
    'Australia',
    'Canada',
    'China',
    'Russia',
    'Germany',
    'Taiwan'
]
const salesData: Array<object> = [
    {
        sales_person:'Steve',
        sales_amount:15000
    },
    {
        sales_person:'John',
        sales_amount:5000
    },
    {
        sales_person:'Roger',
        sales_amount:7000
    },
]
// function to calculate length of the array
function getNumberLength(myArr: Array<number>): void {

    console.log(myArr.length)
}
function getCountriesLength(myArr: Array<string>): void{
    console.log(myArr.length)
}
function getSalesDataLength(myArr: Array<object>): void{
    console.log(myArr.length)
}
getNumberLength(numbers)
getCountriesLength(countries)
getSalesDataLength(salesData)

