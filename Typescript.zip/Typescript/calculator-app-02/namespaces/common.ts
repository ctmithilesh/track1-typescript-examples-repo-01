namespace Common{

    export const AppName = 'My Calculator'
    export function addNum(x: number, y: number): number {
        const result = x + y
        return result
    }
    export function subNum(x: number, y: number): number {
        const result = x - y
        return result
    }
    export function multiplyNum(x: number, y: number): number {
        const result = x * y
        return result
    }
    export function divideNum(x: number, y: number): number {
        const result = x / y
        return result
    }
}
export default Common;



